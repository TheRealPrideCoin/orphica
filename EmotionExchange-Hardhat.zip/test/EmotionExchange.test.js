const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("EmotionExchange", function () {
  let EmotionExchange, contract, owner, user1, user2;
  const emotions = ["Hope", "Despair", "Joy"];

  beforeEach(async function () {
    [owner, user1, user2] = await ethers.getSigners();
    EmotionExchange = await ethers.getContractFactory("EmotionExchange");
    contract = await EmotionExchange.deploy(emotions);
    await contract.deployed();
  });

  it("should allow a user to stake ETH on a valid emotion", async function () {
    await contract.connect(user1).stake("Hope", {
      value: ethers.utils.parseEther("1.0"),
    });

    const totalStake = await contract.getTotalStakes("Hope");
    expect(totalStake).to.equal(ethers.utils.parseEther("1.0"));
  });

  it("should reject staking on an invalid emotion", async function () {
    await expect(
      contract.connect(user1).stake("Anger", {
        value: ethers.utils.parseEther("1.0"),
      })
    ).to.be.revertedWith("Invalid emotion");
  });

  it("should distribute winnings to stakers proportionally", async function () {
    await contract.connect(user1).stake("Joy", {
      value: ethers.utils.parseEther("1.0"),
    });
    await contract.connect(user2).stake("Joy", {
      value: ethers.utils.parseEther("3.0"),
    });

    const initialBalance1 = await ethers.provider.getBalance(user1.address);
    const initialBalance2 = await ethers.provider.getBalance(user2.address);

    const winners = [user1.address, user2.address];
    const tx = await contract.connect(owner).distributeWinnings("Joy", winners);
    await tx.wait();

    const finalBalance1 = await ethers.provider.getBalance(user1.address);
    const finalBalance2 = await ethers.provider.getBalance(user2.address);

    expect(finalBalance1).to.be.gt(initialBalance1);
    expect(finalBalance2).to.be.gt(initialBalance2);
  });
});
